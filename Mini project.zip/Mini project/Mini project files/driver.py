from flask import Flask, render_template, request, flash, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SECRET_KEY'] = 'super secret key'
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql://root:root@localhost/database_table_name'  # Update with your DB details
db = SQLAlchemy(app)

# Define your database models
class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(100), unique=True, nullable=False)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(100), nullable=False)

class FoodItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    description = db.Column(db.String(200), nullable=False)
    quantity = db.Column(db.Integer, nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    user = db.relationship('User', backref='food_items')


class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    food_item_id = db.Column(db.Integer, db.ForeignKey('food_item.id'), nullable=False)
    food_item = db.relationship('FoodItem', backref='cart_items')

# Define your routes and views
@app.route('/')
@app.route('/home')
def home():
    return render_template('home.html')

@app.route('/ngo', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        new_user = User( email=email, password=password)
        db.session.add(new_user)
        db.session.commit()
        flash('Registration successful. You can now log in.', 'success')
        return redirect(url_for('login'))
    return render_template('ngo.html')

@app.route('/ngo', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        user = User.query.filter_by(email=email).first()
        if user and user.password == password:
            # Implement your login logic here
            flash('Login successful', 'success')
            return redirect(url_for('dashboard'))
        else:
            flash('Invalid credentials. Please try again.', 'danger')
    return render_template('ngo.html')

@app.route('/dashboard')
def dashboard():
    # Implement the dashboard view, where users can view food items, add items to the cart, etc.
    return render_template('dashboard.html')

@app.route('/donate', methods=['GET', 'POST'])
def donate():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        quantity = request.form['quantity']
        user_id = 1  # Replace with the user ID of the currently logged-in user
        food_item = FoodItem(name=name, description=description, quantity=quantity, user_id=user_id)
        db.session.add(food_item)
        db.session.commit()
        flash('Food donation successful', 'success')
        return redirect(url_for('dashboard'))
    return render_template('donate.html')

@app.route('/getfood')
def get_food():
    
    return render_template('getfood.html')

@app.route('/cart')
def cart():
    # Implement the cart view, where users can view and manage their cart items
    return render_template('cart.html')

if __name__ == '__main__':
    app.run(debug=True)
